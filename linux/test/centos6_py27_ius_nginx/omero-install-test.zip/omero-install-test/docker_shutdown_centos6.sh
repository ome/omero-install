#!/bin/bash
# All that's needed to get a clean shutdown of the docker container

service postgresql-9.4 stop
