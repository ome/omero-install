#!/bin/bash

STR=${STR:-ius}

if [ $STR == 'scl' ]; then
	echo "value=$STR"
else
	echo "value1=$STR"
fi  

#DIR_S=~/Documents/git-repo/omero-install/linux
#DIR_T=~/Documents/git-repo/ome-documentation/omero/sysadmins/unix/walkthrough
#rm -rf $DIR_T
#mkdir $DIR_T

#cd $DIR_S
#cp docker_virtual* $DIR_T 
#cp install* $DIR_T 
#cp omero* $DIR_T 
#cp README* $DIR_T 
#cp s* $DIR_T 
