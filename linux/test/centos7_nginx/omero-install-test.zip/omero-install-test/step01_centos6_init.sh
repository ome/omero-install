#!/bin/bash

yum -y install epel-release

# installed for convenience
yum -y install unzip wget
