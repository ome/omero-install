#!/bin/bash

yum -y install epel-release
yum -y install centos-release-SCL

# installed for convenience
yum -y install unzip wget tar