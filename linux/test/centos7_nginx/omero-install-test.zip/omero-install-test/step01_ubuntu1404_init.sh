#!/bin/bash

apt-get update

# installed for convenience
apt-get -y install unzip wget